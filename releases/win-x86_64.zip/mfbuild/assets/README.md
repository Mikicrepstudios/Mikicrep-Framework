You are supposed to put here your app assets
